# Part 2:
# Question 7:
select carton_id, (len*width*height) as carton_vol from carton where (len*width*height) > 
(select sum(len*width*height*product_quantity) as total_vol 
from order_items join product using (product_id) where order_id = 10006 group by order_id) 
order by carton_vol limit 1;

# Question 8:
select CUSTOMER_ID, concat(customer_fname,' ',customer_lname) as CUSTOMER_FULLNAME,ORDER_ID,
sum(product_quantity) as TOTAL_PRODUCTS  
from online_customer join order_header using (customer_id) join order_items using (order_id) 
where order_status like 'shipped' group by order_id having TOTAL_PRODUCTS > 10 order by TOTAL_PRODUCTS; 

# Question 9: 
select Order_id,customer_id,concat(customer_fname,' ',customer_lname) as Full_Name,sum(product_quantity) as TOTAL_QUANTITY   
from online_customer join order_header using (customer_id) join order_items using (order_id) 
where order_status like 'shipped' and order_id>10060 group by order_id; 

# Question 10:
select Country,Product_Class_Desc,sum(product_quantity) as Total_Quantity,(Product_Quantity*Product_price) as Total_Value  
from product_class join product using (product_class_code) join order_items using (product_id) 
join order_header using (order_id) join online_customer using (customer_id) join address using (address_id) 
where country not in ('India','USA') and order_status like 'shipped' 
group by product_class_desc order by total_quantity desc limit 1;  
